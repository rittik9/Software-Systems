#include <unistd.h>
 
int main(void) {
  char *binaryPath = "/bin/bash";
  char *arg1 = "-c";
  char *arg2 = "echo \" $HOSTNAME:$PORT from my brave.\"" ;
  char *const env[] = {"HOSTNAME=www.google.com", "PORT=8080", NULL};
 
  execle(binaryPath, binaryPath,arg1, arg2, NULL, env);
 
  return 0;
}