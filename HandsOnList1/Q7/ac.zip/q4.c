#include<stdio.h>
#include <unistd.h>	
#include<fcntl.h>
void main(){
	int fd = open("source", O_RDWR);
	if(fd == -1){
		printf("Unable to open file : %d \n" , perror);
	}
	else{
		printf("File Descriptor of opened file : %d\n", fd);
	}
}