#include<sys/types.h>
#include<sys/stat.h>
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
void main (){
	
	int fd = open("src", 32770);
	if(fd<0){
		printf("Unable to open file\n");
		return;
	}

	int fileMode = fcntl(fd, F_GETFL);
	printf("File Mode: %d\n",fileMode ); //outputs
	// // int fd2 = open("source", fileMode);
	// // fileMode = fcntl(fd2, F_GETFL);
	// printf("%d\n",fileMode );
}