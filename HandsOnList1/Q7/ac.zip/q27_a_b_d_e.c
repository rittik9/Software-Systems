#include <unistd.h>
 
int main(void) {
  char *path = "/bin/ls";
  char *arg = "-il";
  //a
  execl(path,"",arg, NULL);
  //b
  char *filename = "ls"; 
  execlp(filename,filename, arg, NULL);
  
  //d
  char *argv[] = {path, "-a", NULL};
  execv(path, argv);
  //e
  char *argv[] = {filename, "-a", NULL};
  execvp(filename, argv);
  return 0;
}