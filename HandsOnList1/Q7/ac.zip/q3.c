#include<stdio.h>

int main(void){
	
	int fd = creat("demo.txt,", 0766);
       	if(fd != -1)
		printf("File Descriptor for the created file: %d \n", fd);
	return 0;
}

