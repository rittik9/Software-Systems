
/home/shux/coding/os/q16/q16.c
/home/shux/coding/os/q16/q16b.c

#include<sys/types.h>
int main(void){
	symlink("source", "soft_link_through_system_call");
	link("source", "hard_link_through_system_call");
	mkfifo("my_pipe_through_System", 0766);
	return 0;
}
