#include<stdio.h>
#include<unistd.h>
void main(){
	
	int cpid = fork();
	if(cpid){
		printf("Child pid from parent: %d \n", cpid);
	}
	else{
		printf("%dParent pid from child: \n", getppid());
	}
}