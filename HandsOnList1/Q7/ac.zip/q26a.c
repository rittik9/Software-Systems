#include <unistd.h>
 
int main(void) {
  char *path = "tst";
  char *arg = "SHUBHAM";
  execl(path, "",arg, NULL);
  return 0;
}