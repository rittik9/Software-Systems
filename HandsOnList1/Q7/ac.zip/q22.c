#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
void main(){
	
	int cpid = fork();
	int fd = open("src", O_RDWR);
	if(cpid){
		char buf[] = "THIS IS PARENT";
		printf("Child pid from parent: %d \n", cpid);
		wait(0); //waiting for child to write
		lseek(fd, 0, SEEK_END);
		write(fd,buf, sizeof(buf));

	}
	else{
		char buf1[] = "THIS IS CHILD";
		printf("%dParent pid from child: \n", getppid());
		write(fd,buf1, sizeof(buf1));
		close(fd);	
	}
}