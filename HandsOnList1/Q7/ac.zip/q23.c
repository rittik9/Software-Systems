#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
void main(){
	
	int cpid = fork();
	printf("process pid = %d",getpid());
	//int fd = open("src", O_RDWR);
	if(cpid){
		printf("Child pid from parent: %d \n", cpid);
		sleep(100); // Zzzzzz :)
	}
	else{
		char buf1[] = "THIS IS CHILD";//child dies
	}
}