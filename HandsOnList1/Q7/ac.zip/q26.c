#include <unistd.h>
 
int main(void) {
  char *path = "q9";
  char *arg = "";
  execl(path, arg, NULL, NULL);
  return 0;
}