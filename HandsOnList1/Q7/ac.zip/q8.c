#include<sys/types.h>
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
void main (){
	char a[20], b[20];
	printf("Enter filename 1:");
	scanf("%s", a);
	printf("Enter filename 2:");
	scanf("%s", b);

	int input_fd = open(a, O_RDONLY);
	int output_fd = open(b, O_WRONLY);

	char c, ch[8192];
	int i=0, t=0;
	if(input_fd>2){
		do{
			t = read(input_fd, &c , sizeof(c));
			ch[i++] = c;

			if(c == '\n'){
				write(1, &ch, i * sizeof(char));	
				i = 0;
			}
		}while(t>0);
	}
	else
		printf("Uable to open inputFile");
	close(input_fd);
	close(output_fd);
}

